Лекция Тассова - https://www.youtube.com/watch?v=0ZtStXgE6a4&list=PLZ8Sl-GV4E_VG4s-ZZ4cvXlCnLyNKWsPa&index=10

Время - 1:46:20

Должны быть:
- итераторы
- без голых указателей
- обработка исключительных ситуаций
- шаблоны
- концепты
- Доп (дерево, ranges)