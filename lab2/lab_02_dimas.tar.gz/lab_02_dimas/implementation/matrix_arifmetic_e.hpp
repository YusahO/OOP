//
// Created by Дмитрий Жигунов on 20.04.2023.
//

#ifndef LAB_02_MATRIX_ARIFMETIC_E_HPP
#define LAB_02_MATRIX_ARIFMETIC_E_HPP

template<typename T>
template<SumC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator+(const U& val) const
{
    Matrix<T> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[i][k] = _data[i][k] + val;

    return buf;
}
template<typename T>
template<SubC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator-(const U& val) const
{
    Matrix<std::common_type_t<T, U>> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[i][k] = _data[i][k] - val;

    return buf;
}
template<typename T>
template<MulC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator*(const U& val) const
{
    Matrix<T> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[i][k] = _data[i][k] * val;

    return buf;
}
template<typename T>
template<DivC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator/(const U& val) const
{
    _checkDiv(val);
    Matrix<T> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[i][k] = _data[i][k] / val;

    return buf;
}

template<typename T>
template<SumC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::addEntity(const U& val) const
{
    return operator+(val);
}
template<typename T>
template<SubC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::subEntity(const U& val) const
{
    return operator-(val);
}
template<typename T>
template<MulC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::mulEntity(const U& val) const
{
    return operator*(val);
}
template<typename T>
template<DivC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::divEntity(const U& val) const
{
    return operator/(val);
}


template<typename T>
Matrix<T>& Matrix<T>::operator+=(const T& val)
{
    for (auto &elem: *this)
        elem += val;

    return *this;
}
template<typename T>
Matrix<T>& Matrix<T>::operator-=(const T& val)
{
    for (auto &elem: *this)
        elem -= val;

    return *this;
}
template<typename T>
Matrix<T>& Matrix<T>::operator*=(const T& val)
{
    for (auto &elem: *this)
        elem *= val;

    return *this;
}
template<typename T>
Matrix<T>& Matrix<T>::operator/=(const T& val)
{
    for (auto &elem: *this)
        elem /= val;

    return *this;
}


template<typename T>
Matrix<T>& Matrix<T>::addToEntity(const T& val)
{
    return operator+=(val);
}
template<typename T>
Matrix<T>& Matrix<T>::subToEntity(const T& val)
{
    return operator-=(val);
}
template<typename T>
Matrix<T>& Matrix<T>::mulToEntity(const T& val)
{
    return operator*=(val);
}
template<typename T>
Matrix<T>& Matrix<T>::divToEntity(const T& val)
{
    return operator/=(val);
}

#endif //LAB_02_MATRIX_ARIFMETIC_E_HPP
