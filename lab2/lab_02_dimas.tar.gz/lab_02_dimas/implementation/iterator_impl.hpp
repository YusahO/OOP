//
// Created by Дмитрий Жигунов on 15.04.2023.
//

#ifndef LAB_02_ITERATOR_IMPL_HPP
#define LAB_02_ITERATOR_IMPL_HPP

#include "../include/iterator.hpp"


template<typename T>
Iterator<T> Iterator<T>::operator++(int)
{
    Iterator<T> it(*this);

    ++_index;
    return it;
}

template<typename T>
Iterator<T> &Iterator<T>::operator++()
{
    _index++;
    return *this;
}

template<typename T>
Iterator<T> Iterator<T>::operator--(int)
{
    Iterator<T> it(*this);
    --_index;
    return it;
}

template<typename T>
Iterator<T> &Iterator<T>::operator--()
{
    if (_index > 0)
        // Обработка ошибки
        _index--;
    return *this;
}

template<typename T>
const typename Iterator<T>::pointer Iterator<T>::operator->() const
{
    if (_index >= _rows * _cols)
    {
        // Обработка ошибки
        time_t my_time = time(NULL);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
    }
    // .lock Возвращает shared_ptr
    std::shared_ptr<std::shared_ptr<T[]>[]> data_ptr = _data->lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
typename Iterator<T>::pointer Iterator<T>::operator->()
{
    if (_index >= _rows * _cols)
    {
//         Обработка ошибки
        time_t my_time = time(NULL);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
    }
//     .lock Возвращает shared_ptr
    std::shared_ptr<std::shared_ptr<T[]>[]> data_ptr = _data.lock();
//     Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
typename Iterator<T>::reference Iterator<T>::operator*() const
{
    _checkValid("iterator is not valid");
    _checkIndex("bad initializer");
    // .lock Возвращает shared_ptr
    SharedPtr<SharedPtr<T[]>[]> data_ptr = _data.lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
const typename Iterator<T>::reference Iterator<T>::operator*()
{
    _checkValid("iterator is not valid");
    _checkIndex("bad initializer");
//     .lock Возвращает shared_ptr
    SharedPtr<typename Matrix<T>::MatrixRow[]> data_ptr = _data.lock();
//     Получение индекса по матрице

    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
typename Iterator<T>::reference Iterator<T>::operator[](int ind) const
{
    std::shared_ptr<T[]> buf = _data.lock();
    return buf.get() + index;
}

template<typename T>
void Iterator<T>::_checkIndex(const std::string msg)
{
    if (_index < _rows * _cols)
        return;
    // Обработка ошибки
    time_t my_time = time(nullptr);
    throw ErrorIteratorIndex(__FILE__, __LINE__, ctime(&my_time), msg.data());
}

template<typename T>
void Iterator<T>::_checkValid(const std::string msg)
{
    if (!isValid())
    {
        // Обработка ошибки
        time_t my_time = time(nullptr);
        throw ErrorIterator(__FILE__, __LINE__, ctime(&my_time), msg.data());
    }
}

template<typename T>
Iterator<T> &Iterator<T>::operator=(const Iterator<T> &it)
{
    _rows = it._rows;
    _cols = it._cols;
    _index = it._index;
    _data = it._data;

    return *this;
}
template<typename T>
Iterator<T> Iterator<T>::next()
{
    return ++this;
}
template<typename T>
Iterator<T> Iterator<T>::prev()
{
    return --this;
}

template<typename T>
Iterator<T> Iterator<T>::operator-(const int value) const
{
    return operator+(-value);
}
template<typename T>
Iterator<T> Iterator<T>::operator+(const int value) const
{
    Iterator<T> it(*this);
    if (value < 0 && it._index < static_cast<size_t>(-value))
        it._index = 0;
    else
        it._index += value;

    if (it._index < 0)
        it._index = 0;
    else if (it._index > _rows * _cols)
        it._index = _rows * _cols;

    return it;
}

#endif //LAB_02_ITERATOR_IMPL_HPP
