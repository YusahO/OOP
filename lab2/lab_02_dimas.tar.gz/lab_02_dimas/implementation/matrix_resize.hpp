//
// Created by Дмитрий Жигунов on 19.04.2023.
//

#ifndef LAB_02_MATRIX_RESIZE_HPP
#define LAB_02_MATRIX_RESIZE_HPP


template<typename T>
void Matrix<T>::deleteCol(SizeType ind)
{
    _checkLimit(ind, _cols - 1);
    auto tmp = _allocate_mem(_rows, _cols - 1);

    SizeType ci = 0, ri = 0;
    while (ci < _cols)
    {
        if (ci != ind)
        {
            for (SizeType i = 0; i < _rows; ++i)
                tmp[i][ri] = _data[i][ci];
            ri++;
        }
        ci++;
    }

    _data = tmp;
    --_cols;
}
template<typename T>
void Matrix<T>::deleteRow(SizeType ind)
{
    _checkLimit(ind, _rows - 1);

    auto tmp = _allocate_mem(_rows - 1, _cols);

    SizeType ri = 0, ci = 0;
    while (ri < _rows) {
        if (ri != ind) {
            for (SizeType i = 0; i < _cols; ++i)
                tmp[ci][i] = _data[ri][i];
            ++ci;
        }
        ++ri;
    }

    _data = tmp;
    --_rows;
}

template<typename T>
void Matrix<T>::insertCol(SizeType ind, const T &fill_val)
{
    _checkLimit(ind, _cols);

    resizeCols(_cols + 1);
    for (SizeType i = 0; i < _rows; i++)
        _data[i][_cols - 1] = fill_val;
    _moveCol(_cols - 1, ind);
}
template<typename T>
void Matrix<T>::insertRow(SizeType ind, const T &fill_val)
{
    _checkLimit(ind, _rows);

    resizeRows(_rows + 1);
    fill(end() - static_cast<int>(_cols), end(), fill_val);
    _moveRow(_rows - 1, ind);
}


template<typename T>
void Matrix<T>::_moveRow(SizeType ind, SizeType new_ind)
{
    auto tmp = _data[ind];
    for (SizeType i = ind; i > new_ind; --i)
        _data[i] = _data[i - 1];
    for (SizeType i = ind; i < new_ind; ++i)
        _data[i] = _data[i + 1];
    _data[new_ind] = tmp;
}
template<typename T>
void Matrix<T>::_moveCol(SizeType ind, SizeType new_ind)
{
    for (SizeType i = 0; i < _rows; ++i)
    {
        auto tmp = _data[i][ind];
        for (SizeType k = ind; k > new_ind; --k)
            _data[i][k] = _data[i][k - 1];
        for (SizeType k = ind; k < new_ind; ++k)
            _data[i][k] = _data[i][k + 1];
        _data[i][new_ind] = tmp;
    }
}

template<typename T>
void Matrix<T>::resizeCols(SizeType n_cols, const T &fill)
{
    resize(_rows, n_cols, fill);
}
template<typename T>
void Matrix<T>::resizeRows(SizeType n_rows, const T &fill)
{
    resize(n_rows, _cols, fill);
}

template<typename T>
void Matrix<T>::resize(SizeType n_rows, SizeType n_cols, const T &fill)
{
    if (n_rows == 0 || n_cols == 0)
        n_rows = n_cols = 0;

    auto buf = _allocate_mem(n_rows, n_cols);
    for (SizeType i = 0; i < std::min(_rows, n_rows); ++i)
    {
        for (SizeType k = 0; k < std::min(_cols, n_cols); ++k)
            buf[i][k] = _data[i][k];
        for (SizeType j = _cols; j < n_cols; ++j)
            buf[i][j] = fill;
    }

    for (SizeType i = _rows; i < n_rows; ++i)
        for (SizeType k = 0; k < n_cols; ++k)
            buf[i][k] = fill;

    _rows = n_rows;
    _cols = n_cols;
    _data = buf;
}

#endif //LAB_02_MATRIX_RESIZE_HPP
