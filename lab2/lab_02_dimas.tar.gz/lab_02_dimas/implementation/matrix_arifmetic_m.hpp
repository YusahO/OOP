//
// Created by Дмитрий Жигунов on 19.04.2023.
//

#ifndef LAB_02_MATRIX_ARIFMETIC_M_HPP
#define LAB_02_MATRIX_ARIFMETIC_M_HPP


template<typename T>
template<SumC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator+(const Matrix<U> &it) const
{
    _checkSizes(it);

    // Либо using result_type = std::conditional_t<sizeof(T1) >= sizeof(T2), T1, T2>;
    Matrix<std::common_type_t<T, U>> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[i][k] = _data[i][k] + it[i][k];
    return buf;
}
template<typename T>
template<SubC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator-(const Matrix<U> &it) const
{
    _checkSizes(it);

    Matrix<std::common_type_t<T, U>> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[i][k] = _data[i][k] - it[i][k];
    return buf;
}
template<typename T>
template<MulC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator*(const Matrix<U> &it) const
{
    _checkSizesMulti(it);

    Matrix<std::common_type_t<T, U>> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < it.GetCols(); k++)
            for (SizeType p = 0; p < _cols; p++)
                buf[i][k] += _data[i][p] * it[p][k];
    return buf;
}
template<typename T>
template<DivC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::operator/(const Matrix<U> &it) const
{
    Matrix<std::common_type_t<T, U>> buf(_rows, _cols, it);
    buf = buf.inverse();
    return operator*(buf);
}


template<typename T>
template<SumC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::addMatrix(const Matrix<U> &it) const
{
    return operator+(it);
}
template<typename T>
template<SubC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::subMatrix(const Matrix<U> &it) const
{
    return operator-(it);
}
template<typename T>
template<MulC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::mulMatrix(const Matrix<U> &it) const
{
    return operator*(it);
}
template<typename T>
template<DivC<T> U>
Matrix<std::common_type_t<T, U>> Matrix<T>::divMatrix(const Matrix<U> &it) const
{
    return operator/(it);
}


template<typename T>
Matrix<T> &Matrix<T>::operator+=(const Matrix<T> &it)
{
    _checkSizes(it);

    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] += it[i][k];
    return *this;
}

template<typename T>
Matrix<T> &Matrix<T>::operator-=(const Matrix<T> &it)
{
    _checkSizes(it);

    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] -= it[i][k];
    return *this;
}

template<typename T>
Matrix<T>& Matrix<T>::operator*=(const Matrix<T> &it)
{
    _checkSizesMulti(it);

    Matrix<T> buf(_rows, it._cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < it._cols; k++)
            for (SizeType p = 0; p < _cols; p++)
                buf[i][k] += _data[i][p] * it[p][k];

    *this = buf;
    return *this;
}

template<typename T>
Matrix<T> &Matrix<T>::operator/=(const Matrix<T> &it)
{
    Matrix<T> buf(it);
    buf = buf.inverse();
    return operator*=(buf);
}


template<typename T>
Matrix<T> &Matrix<T>::addToMatrix(const Matrix &it)
{
    return operator+=(it);
}
template<typename T>
Matrix<T> &Matrix<T>::subToMatrix(const Matrix &it)
{
    return operator-=(it);
}
template<typename T>
Matrix<T> &Matrix<T>::mulToMatrix(const Matrix &it)
{
    return operator*=(it);
}

template<typename T>
Matrix<T> &Matrix<T>::divToMatrix(const Matrix &it)
{
    return operator/=(it);
}

#endif //LAB_02_MATRIX_ARIFMETIC_M_HPP
