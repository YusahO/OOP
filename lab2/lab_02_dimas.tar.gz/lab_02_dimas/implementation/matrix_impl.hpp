//
// Created by Дмитрий Жигунов on 16.04.2023.
//

#ifndef LAB_02_MATRIX_IMPL_HPP
#define LAB_02_MATRIX_IMPL_HPP

template<typename T>
void Matrix<T>::_checkType()
{
    if (std::is_arithmetic_v<T> == 0)
    {
        // Обработка ошибки
        time_t my_time = time(nullptr);
        throw ErrorType(__FILE__, __LINE__, ctime(&my_time), "not arithmetic type for matrix");
    }
}


template<typename T>
Matrix<T> &Matrix<T>::operator=(const Matrix &matr)
{
    _rows = matr._rows;
    _cols = matr._cols;
    _data = _allocate_mem(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] = matr._data[i][k];

    return *this;
}
template<typename T>
Matrix<T> &Matrix<T>::operator=(Matrix &&matr) noexcept
{
    _rows = matr._rows;
    _cols = matr._cols;
    _data = matr._data;

    return *this;
}
template<typename T>
std::ostream &operator<<(std::ostream &out, const Matrix<T> &matrix)
{
    for (SizeType i = 0; i < matrix.GetRows(); i++)
    {
        for (SizeType k = 0; k < matrix.GetCols(); k++)
        {
            out << matrix[i][k] << " ";
        }
        out << std::endl;
    }

    return out;
}

template<typename T>
Matrix<T>::Matrix(const SizeType rows, const SizeType cols): BaseMatrix(rows, cols)
{
    _checkType();
    _data = _allocate_mem(_rows, _cols);
}
template<typename T>
Matrix<T>::Matrix(const Matrix &matrix): BaseMatrix(matrix._rows, matrix._cols)
{
    _checkType();
    _data = _allocate_mem(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] = matrix[i][k];
}
template<typename T>
template<Convertable<T> U>
Matrix<T>::Matrix(const Matrix<U> &matrix): BaseMatrix(matrix.GetRows(), matrix.GetCols())
{
    _checkType();
    _data = _allocate_mem(_rows, _cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] = matrix[i][k];
}
template<typename T>
template<ContainerC Con>
requires Convertable<typename Con::value_type::value_type, T> && Assignable<typename Con::value_type::value_type, T>
Matrix<T>::Matrix(const Con &matrix)
{
    size_t rows = matrix.size();
    size_t cols = matrix[0].size();
    for (const auto &itlist: matrix)
        if (itlist.size() != cols)
        {
            // Обработка ошибки
            time_t my_time = time(nullptr);
            throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
        }

    _rows = rows;
    _cols = cols;
    _data = _allocate_mem(_rows, _cols);

    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] = matrix[i][k];

}
template<typename T>
Matrix<T>::Matrix(SizeType rows, SizeType cols, const T *matrix): BaseMatrix(rows, cols)
{
    _checkType();
    _data = _allocate_mem(rows, cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] = matrix[i*cols + k];
}
template<typename T>
Matrix<T>::Matrix(SizeType rows, SizeType cols, Iterator<T> st): BaseMatrix(rows, cols)
{
    _checkType();
    _data = _allocate_mem(rows, cols);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            _data[i][k] = *(st++);
}
template<typename T>
Matrix<T>::Matrix(const SizeType rows, const SizeType cols, const T &filler): BaseMatrix(rows, cols)
{
    _checkType();
    _data = _allocate_mem(_rows, _cols);
    for (SizeType i = 0; i < rows; i++)
        for (SizeType k = 0; k < cols; k++)
            _data.get()[i][k] = filler;
}
template<typename T>
Matrix<T>::Matrix(std::initializer_list<std::initializer_list<T>> lt)
{
    _checkType();
    SizeType rows = lt.size();
    auto init_list = lt.begin();
    SizeType cols = init_list->size();

    for (const auto &itlist: lt)
        if (itlist.size() != cols)
        {
            // Обработка ошибки
            time_t my_time = time(nullptr);
            throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
        }

    // Инициализация
    _rows = rows;
    _cols = cols;
    _data = _allocate_mem(_rows, _cols);
    SizeType ind = 0;
    for (const auto &ilist: lt)
        for (const auto &klist: ilist)
        {
            _data.get()[ind / cols][ind % cols] = klist;
            ind++;
        }
}
template <typename T>
Matrix<T>::Matrix(Matrix &&matrix) noexcept: BaseMatrix(matrix._rows, matrix._cols)
{
    _data = matrix._data;
}

template<typename T>
const T &Matrix<T>::at(const SizeType row, const SizeType col) const
{
    return _data[row][col];
}
template<typename T>
T &Matrix<T>::at(const SizeType row, const SizeType col)
{
    return _data[row][col];
}
template<typename T>
void Matrix<T>::set(SizeType n, SizeType m, T val)
{
    _data[n][m] = val;
}
template<typename T>
T& Matrix<T>::operator()(SizeType row, SizeType col)
{
    return (*this)[row][col];
}

template <typename T>
typename Matrix<T>::MatrixRow Matrix<T>::operator[](SizeType row)
{
    return _data[row];
}
template<typename T>
const typename Matrix<T>::MatrixRow Matrix<T>::operator[](const SizeType row) const
{
    return _data[row];
}


template<typename T>
Matrix<T> &Matrix<T>::operator=(std::initializer_list<std::initializer_list<T>> lt)
{
    SizeType rows = lt.size();
    auto init_list = lt.begin();
    SizeType cols = init_list->size();

    for (const auto &itlist: lt)
        if (itlist.size() != cols)
        {
            // Обработка ошибки
            time_t my_time = time(nullptr);
            throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
        }

    // Инициализация
    _rows = rows;
    _cols = cols;
    _data = _allocate_mem(_rows, _cols);
    SizeType ind = 0;
    for (const auto &ilist: lt)
        for (const auto &klist: ilist)
        {
            _data.get()[ind / cols].get()[ind % cols] = klist;
            ind++;
        }

    return *this;
}


template<typename T>
shared_ptr<typename Matrix<T>::MatrixRow[]> Matrix<T>::_allocate_mem(const SizeType rows, const SizeType cols)
{
    // Выделение памяти из rows строк под массив указателей
    shared_ptr<MatrixRow[]> data_mem = nullptr;
    try
    {
        data_mem.reset(new MatrixRow[rows]);
        for (SizeType i = 0; i < rows; i++)
            // Замена памяти в массиве указателей на массив cols
            data_mem[i].reset(new T[cols], cols);
    }
    catch (std::bad_alloc &err)
    {
        // Обработка ошибки
        time_t my_time = time(nullptr);
        throw ErrorMemory(__FILE__, __LINE__, ctime(&my_time), "bad alloc");
    }
    return data_mem;
}

template<typename T>
void Matrix<T>::fill(const Iterator<T> st, const Iterator<T> end, const T &val)
{
    for (auto pr = st; pr < end; pr++)
        *pr = val;
}
template<typename T>
void Matrix<T>::fill(Iterator<T> st, IteratorConst<T> val_st, IteratorConst<T> val_end)
{
    auto source_it = val_st;
    auto it = st;
    while (!it.isEnd() && source_it < val_end)
    {
        *it = *source_it;
        ++it, ++source_it;
    }
}
template<typename T>
void Matrix<T>::fill(Iterator<T> st, Iterator<T> val_st, Iterator<T> val_end)
{
    auto source_it = val_st;
    auto it = st;
    while (!it.isEnd() && source_it < val_end)
    {
        *it = *source_it;
        ++it, ++source_it;
    }
}


// Ужатие матрицы (копирование без ex_row и ex_col)
template <typename T>
static void _excludeCopy(Matrix<T>& target, const Matrix<T>& source, SizeType ex_row, SizeType ex_col)
{
    SizeType row_index, col_index;
    for (SizeType i = 0; i < source.GetRows() - 1; ++i)
        for (SizeType k = 0; k < source.GetCols() - 1; ++k) {
            row_index = i >= ex_row ? i + 1 : i;
            col_index = k >= ex_col ? k + 1 : k;
            target[i][k] = source[row_index][col_index];
        }
}


#endif //LAB_02_MATRIX_IMPL_HPP
