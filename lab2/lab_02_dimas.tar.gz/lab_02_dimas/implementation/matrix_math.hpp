//
// Created by Дмитрий Жигунов on 21.04.2023.
//

#ifndef LAB_02_MATRIX_MATH_HPP
#define LAB_02_MATRIX_MATH_HPP


template<typename T>
template<typename U>
void Matrix<T>::_checkSizes(Matrix<U> matr) const
{
    if (_rows != matr.GetRows() || _cols != matr.GetCols())
    {
        // Обработка ошибки
        time_t my_time = time(NULL);
        throw ErrorCompatibility(__FILE__, __LINE__, ctime(&my_time), "not equal sizes for matrix");
    }
}
template<typename T>
template<typename U>
void Matrix<T>::_checkSizesMulti(Matrix<U> matr) const
{
    if (_cols != matr.GetRows())
    {
        // Обработка ошибки
        time_t my_time = time(nullptr);
        throw ErrorCompatibility(__FILE__, __LINE__, ctime(&my_time), "bad sizes for multi matrix");
    }
}
template<typename T>
template<typename U>
void Matrix<T>::_checkDiv(const U& val) const
{
    if (val == 0)
    {
        // Обработка ошибки
        time_t my_time = time(NULL);
        throw ErrorZeroDiv(__FILE__, __LINE__, ctime(&my_time), "not equal sizes for matrix");
    }
}
template<typename T>
void Matrix<T>::_checkLimit(SizeType ind, SizeType limit) const
{
    if (ind >= limit)
    {
        // Обработка ошибки
        time_t my_time = time(nullptr);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "index is not under limit");
    }
}
template<typename T>
bool Matrix<T>::isSquare() const
{
    return _rows == _cols;
}
template<typename T>
Matrix<T> Matrix<T>::operator-()
{
    Matrix<T> buf(_rows, _cols);
    for (SizeType i = 0; i < _rows; ++i)
        for (SizeType j = 0; j < _cols; ++j)
            buf[i][j] = -_data[i][j];
    return buf;
}

template<typename T>
void Matrix<T>::reverse(Iterator<T> st, Iterator<T> end)
{
    --end;
    for (auto pr = st, pr2 = end; pr < pr2; pr++, pr2--)
        std::swap(*pr, *pr2);
}
template<typename T>
Matrix<T> Matrix<T>::transpose()
{
    Matrix<T> buf = *this;
    buf._data = _allocate_mem(_cols, _rows);
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf[k][i] = _data[i][k];
    std::swap(buf._rows, buf._cols);
    return buf;
}

// Определитель
template <typename T>
T Matrix<T>::_det(const Matrix<T>& matrix)
{
    if (matrix.GetRows() == 2)
        return matrix[0][0] * matrix[1][1] - matrix[1][0] * matrix[0][1];
    if (matrix.GetRows() == 1)
        return matrix[0][0];

    Matrix<T> tmp(matrix.GetRows() - 1, matrix.GetCols() - 1);
    T res = {};
    for (SizeType i = 0; i < matrix.GetRows(); ++i) {
        _excludeCopy(tmp, matrix, 0, i);
        T minor = _det(tmp);
        if (i & 1)
            minor = -minor;
        res += minor * matrix[0][i];
    }

    return res;
}
template <typename T>
T Matrix<T>::det()
{
    if (!isSquare())
    {
        time_t my_time = time(NULL);
        throw ErrorCompatibility(__FILE__, __LINE__, ctime(&my_time), "matrix must be square-type");
    }
    return _det(*this);
}

template <typename T>
bool Matrix<T>::isSquare()
{
    return _rows == _cols;
}
// Смена знака матрицы
template <typename T>
Matrix<T> Matrix<T>::negative()
{
    Matrix<T> buf = *this;
    for (SizeType i = 0; i < _rows; i++)
        for (SizeType k = 0; k < _cols; k++)
            buf._data[i][k] = -_data[i][k];
    return buf;
}
// Инверсия матрицы
template <typename T>
Matrix<T> Matrix<T>::inverse()
{
    // Поиск определителя
    T det = this->det();
    if (!isSquare() || !det)
    {
        time_t my_time = time(NULL);
        throw ErrorCompatibility(__FILE__, __LINE__, ctime(&my_time), "matrix must be square-type");
    }
    // Вычисление обратной матрицы
    Matrix<T> res(_rows, _cols);
    Matrix<T> buf(_rows - 1, _cols - 1);
    T value = {};

    for (SizeType i = 0; i < _rows; ++i)
        for (SizeType j = 0; j < _cols; ++j)
        {
            _excludeCopy(buf, *this, i, j);
            value = buf.det() / det;
            if ((i + j) &  1)
                value = -value;
            res[j][i] = value;
        }

    return res;
}

#endif //LAB_02_MATRIX_MATH_HPP
