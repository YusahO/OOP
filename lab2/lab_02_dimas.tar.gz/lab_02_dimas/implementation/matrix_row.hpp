//
// Created by Дмитрий Жигунов on 21.04.2023.
//

#ifndef LAB_02_MATRIX_ROW_HPP
#define LAB_02_MATRIX_ROW_HPP

template<typename T>
Matrix<T>::MatrixRow::MatrixRow()
{
    _data = nullptr;
    _size = 0;
}

template<typename T>
T &Matrix<T>::MatrixRow::operator[](SizeType index)
{
    if (index >= _size)
    {
        time_t my_time = time(nullptr);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "index of row/column is wrong");
    }

    return _data[index];
}
template <typename T>
const T &Matrix<T>::MatrixRow::operator[](SizeType index) const {
    if (index >= _size)
    {
        time_t my_time = time(nullptr);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "index of row/column is wrong");
    }

    return _data[index];
}

template<typename T>
void Matrix<T>::MatrixRow::reset(T *data, SizeType len)
{
    _size = len;
    _data.reset(data);
}
template<typename T>
void Matrix<T>::MatrixRow::reset()
{
    _size = 0;
    // Сброс значения по указателю
    _data.reset();
}

#endif //LAB_02_MATRIX_ROW_HPP
