//
// Created by Дмитрий Жигунов on 21.04.2023.
//

#ifndef LAB_02_ITERATOR_CONST_IMPL_HPP
#define LAB_02_ITERATOR_CONST_IMPL_HPP

#include "../include/iterator_const.hpp"

template<typename T>
void IteratorConst<T>::_checkIndex(const std::string& msg) const
{
    if (_index < _rows * _cols)
        return;
    time_t my_time = time(NULL);
    throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), msg.data());
}
template<typename T>
void IteratorConst<T>::_checkValid(const std::string& msg) const
{
    if (isValid())
        return;
    time_t my_time = time(NULL);
    throw ErrorIterator(__FILE__, __LINE__, ctime(&my_time), msg.data());
}
template<typename T>
typename IteratorConst<T>::reference IteratorConst<T>::operator[](int ind) const
{
    std::shared_ptr<T[]> buf = _data.lock();
    return buf.get() + index;
}


template<typename T>
IteratorConst<T> &IteratorConst<T>::operator++()
{
    if (_index < _rows * _cols)
        ++_index;
    return *this;
}
template<typename T>
IteratorConst<T> IteratorConst<T>::operator++(int)
{
    IteratorConst<T> it(*this);
    ++_index;
    return it;
}
template<typename T>
IteratorConst<T> &IteratorConst<T>::operator--()
{
    if (_index < _rows * _cols)
        --_index;
    return *this;
}
template<typename T>
IteratorConst<T> IteratorConst<T>::operator--(int)
{
    IteratorConst<T> it(*this);
    --_index;
    return it;
}
template<typename T>
IteratorConst<T> IteratorConst<T>::next()
{
    return operator++();
}
template<typename T>
IteratorConst<T> IteratorConst<T>::prev()
{
    return operator--();
}

template<typename T>
IteratorConst<T> &IteratorConst<T>::operator=(const IteratorConst<T> &it)
{
    _rows = it._rows;
    _cols = it._cols;
    _index = it._index;
    _data = it._data;

    return *this;
}


template<typename T>
const typename IteratorConst<T>::reference IteratorConst<T>::operator*() const
{
    _checkValid("IteratorConst points on NULL");
    _checkIndex("Bad index in IteratorConst for operator *");
    // .lock Возвращает shared_ptr
    shared_ptr<typename Matrix<T>::MatrixRow[]> data_ptr = _data.lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}
template<typename T>
const typename IteratorConst<T>::pointer IteratorConst<T>::operator->() const
{
    _checkValid("IteratorConst points on NULL");
    _checkIndex("Bad index in IteratorConst for operator const ->");
    // .lock Возвращает shared_ptr
    shared_ptr<shared_ptr<T[]>[]> data_ptr = _data.lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
IteratorConst<T> IteratorConst<T>::operator-(const int value) const
{
    return operator+(-value);
}
template<typename T>
IteratorConst<T> IteratorConst<T>::operator+(const int value) const
{
    Iterator<T> it(*this);
    if (value < 0 && it._index < static_cast<size_t>(-value))
        it._index = 0;
    else
        it._index += value;

    if (it._index < 0)
        it._index = 0;
    else if (it._index > _rows * _cols)
        it._index = _rows * _cols;

    return it;
}

#endif //LAB_02_ITERATOR_CONST_IMPL_HPP
