//
// Created by Дмитрий Жигунов on 21.04.2023.
//

#ifndef LAB_02_MATRIX_ITERATOR_HPP
#define LAB_02_MATRIX_ITERATOR_HPP


template<typename T>
Iterator<T> Matrix<T>::begin() noexcept
{
    return Iterator<T>(*this, 0);
}
template<typename T>
Iterator<T> Matrix<T>::end() noexcept
{
    return Iterator<T>(*this, _rows * _cols);
}
template<typename T>
IteratorConst<T> Matrix<T>::begin() const noexcept
{
    return IteratorConst<T>(*this, 0);
}
template<typename T>
IteratorConst<T> Matrix<T>::end() const noexcept
{
    return IteratorConst<T>(*this, _rows * _cols);
}
template<typename T>
IteratorConst<T> Matrix<T>::cbegin() const noexcept
{
    return IteratorConst<T>(*this, 0);
}
template<typename T>
IteratorConst<T> Matrix<T>::cend() const noexcept
{
    return IteratorConst<T>(*this, _rows * _cols);
}
template<typename T>
IteratorReverse<T> Matrix<T>::rbegin() noexcept
{
    return IteratorReverse<T>(*this, _rows * _cols - 1);
}
template<typename T>
IteratorReverse<T> Matrix<T>::rend() noexcept
{
    return IteratorReverse<T>(*this, -1);
}
template<typename T>
IteratorReverseConst<T> Matrix<T>::rbegin() const noexcept
{
    return IteratorReverseConst<T>(*this, _rows * _cols - 1);
}
template<typename T>
IteratorReverseConst<T> Matrix<T>::rend() const noexcept
{
    return IteratorReverseConst<T>(*this, -1);
}
template<typename T>
IteratorReverseConst<T> Matrix<T>::crbegin() const noexcept
{
    return IteratorReverseConst<T>(*this, _rows * _cols - 1);
}
template<typename T>
IteratorReverseConst<T> Matrix<T>::crend() const noexcept
{
    return IteratorReverseConst<T>(*this, -1);
}



#endif //LAB_02_MATRIX_ITERATOR_HPP
