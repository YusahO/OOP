//
// Created by Дмитрий Жигунов on 15.04.2023.
//

#ifndef LAB_02_IteratorReverse_IMPL_HPP
#define LAB_02_IteratorReverse_IMPL_HPP

#include "../include/iterator_reverse.hpp"

template<typename T>
IteratorReverse<T> IteratorReverse<T>::operator++(int)
{
    IteratorReverse<T> it(*this);

    --_index;
    return it;
}

template<typename T>
IteratorReverse<T> &IteratorReverse<T>::operator++()
{
    --_index;
    return *this;
}

template<typename T>
IteratorReverse<T> IteratorReverse<T>::operator--(int)
{
    IteratorReverse<T> it(*this);
    ++_index;
    return it;
}

template<typename T>
IteratorReverse<T> &IteratorReverse<T>::operator--()
{
    if (_index > 0)
        // Обработка ошибки
        ++_index;
    return *this;
}

template<typename T>
const typename IteratorReverse<T>::pointer IteratorReverse<T>::operator->() const
{
    if (_index >= _rows * _cols)
    {
        // Обработка ошибки
        time_t my_time = time(NULL);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
    }
    // .lock Возвращает shared_ptr
    shared_ptr<shared_ptr<T[]>[]> data_ptr = _data->lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
T *IteratorReverse<T>::operator->()
{
    if (_index >= _rows * _cols)
    {
        // Обработка ошибки
        time_t my_time = time(NULL);
        throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), "bad initializer");
    }
    // .lock Возвращает shared_ptr
    shared_ptr<shared_ptr<T[]>[]> data_ptr = _data.lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
const typename IteratorReverse<T>::reference IteratorReverse<T>::operator*() const
{
    _checkValid("IteratorReverse is not valid");
    _checkIndex("bad initializer");
    // .lock Возвращает shared_ptr
    shared_ptr<shared_ptr<T[]>[]> data_ptr = _data.lock();
    // Получение индекса по матрице
    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
T &IteratorReverse<T>::operator*()
{
    _checkValid("IteratorReverse is not valid");
    _checkIndex("bad initializer");
    // .lock Возвращает shared_ptr
    shared_ptr<typename Matrix<T>::MatrixRow[]> data_ptr = _data.lock();
    // Получение индекса по матрице

    return data_ptr[_index / _cols][_index % _cols];
}

template<typename T>
void IteratorReverse<T>::_checkIndex(const std::string msg)
{
    if (_index < _rows * _cols)
        return;
    // Обработка ошибки
    time_t my_time = time(nullptr);
    throw ErrorIndex(__FILE__, __LINE__, ctime(&my_time), msg.data());
}

template<typename T>
void IteratorReverse<T>::_checkValid(const std::string msg)
{
    if (!isValid())
    {
        // Обработка ошибки
        time_t my_time = time(nullptr);
        throw ErrorIterator(__FILE__, __LINE__, ctime(&my_time), msg.data());
    }
}
template<typename T>
typename IteratorReverse<T>::reference IteratorReverse<T>::operator[](int ind) const
{
    std::shared_ptr<T[]> buf = _data.lock();
    return buf.get() + index;
}

template<typename T>
IteratorReverse<T> &IteratorReverse<T>::operator=(const IteratorReverse<T> &it)
{
    _rows = it._rows;
    _cols = it._cols;
    _index = it._index;
    _data = it._data;

    return *this;
}

template<typename T>
IteratorReverse<T> IteratorReverse<T>::next()
{
    return --this;
}
template<typename T>
IteratorReverse<T> IteratorReverse<T>::prev()
{
    return ++this;
}

template<typename T>
IteratorReverse<T> IteratorReverse<T>::operator-(const int value) const
{
    return operator+(-value);
}
template<typename T>
IteratorReverse<T> IteratorReverse<T>::operator+(const int value) const
{
    IteratorReverse<T> it(*this);
    if (value < 0 && it._index < static_cast<size_t>(-value))
        it._index = 0;
    else
        it._index -= value;

    if (it._index < 0)
        it._index = 0;
    else if (it._index > _rows * _cols)
        it._index = _rows * _cols;

    return it;
}

#endif //LAB_02_IteratorReverse_IMPL_HPP
