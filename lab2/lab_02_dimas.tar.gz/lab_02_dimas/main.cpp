#include <iostream>
#include "include/matrix.hpp"


using std::cout, std::endl;
using namespace MyMatrix;

int main()
{
    cout << "=== CONSTRUCTORS ===" << endl;
    {
        size_t q = 2, w = 3;
        cout << "Constructor with two numbers:\n";
        Matrix<int> a(q, w);
        cout << a << endl;
        cout << "Constructor with filler \tMatrix<float> b(2, 3, 26):\n";
        Matrix<float> b(q, w, 26);
        cout << b << endl;
        cout << "Constructor with initialization list \tMatrix<float> c({ { 1., 2. }, { -3., -4. } }):\n";
        Matrix<float> c({{1.,  2.},
                         {-3., -4.}});
        cout << c << endl;
        cout << "Constructor with copy \tMatrix<float> d(c):\n";
        const Matrix<float>& d(c);
        cout << d << endl;
        cout << "Constructor for C matrix \tint c_matr[][3] = {{1, 2, 3}, {4, 5, 6}}:\n";
        int c_matr[][3] = {{1, 2, 3}, {4, 5, 6}};
        Matrix<int> cpp_matr(2, 3, reinterpret_cast<const int *>(c_matr));
        cout << cpp_matr << endl;
        cout << "Constructor with iterator \tMatrix<int> ee(2, 2, e.begin()):\n";
        Matrix<int> e = {{1, 2, 3}, {4, 5, 6}};
        Matrix<int> ee(2, 2, e.begin());
        cout << ee << endl;
        cout << "Constructor from float to int \tMatrix<int> f(c):\n";
        Matrix<int> f(c);
        cout << f << endl;

        //Создание матрицы из массива
        cout << "Constructor with vectors \tv { {1, 2}, {3, 4}, {5, 6} } g(v):\n";
        std::vector<std::vector<int>> v { {1, 2}, {3, 4}, {5, 6} };
        Matrix<int> g(v);
        cout << g << endl;

        cout << endl << endl;

    }

    cout << "=== GET/SET ELEMENTS ===" << endl;
    {
        Matrix<int> a = {{-0, -1, -2}, {-10, -11, -12}};
        cout << "INIT A\n" << a;
        cout << "Get element by id by [1][1] and .at(1, 2)\n";
        cout << a[1][1] << "\t" << a.at(1, 2) << endl;
        cout << "Set element by id by [1][1] = 0 and .at(1, 2) and .set(1, 2, 0) = 0\n";
        a[1][1] = 999;
        a.at(1, 2) = 999999;
        a.set(1, 2, 999999);
        cout << a[1][1] << "\t" << a.at(1, 2)<< endl;

    }

    cout << "=== MATH with matrix ===" << endl;
    {
        Matrix<float> a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        Matrix<float> b({{7, 4, 2}, {1, -5, -6}, {1, 0, 1}});
        Matrix<float> buf;
        cout << "INIT A\n" << a << endl;
        cout << "INIT B\n" << b << endl;
        cout << "--- MATH BETWEEN MATRIX (operations) ---" << endl;
        buf = a + b;
        cout << "A + B\n" << buf << endl;
        buf = a - b;
        cout << "A - B\n" << buf << endl;
        buf = a * b;
        cout << "A * B\n" << buf << endl;
        buf = a / b;
        cout << "A / B\n" << buf << endl;
        cout << "\n";

        cout << "--- MATH BETWEEN MATRIX (methods) ---" << endl;
        buf = a.addMatrix(b);
        cout << "A + B\n" << buf << endl;
        buf = a.subMatrix(b);
        cout << "A - B\n" << buf << endl;
        buf = a.mulMatrix(b);
        cout << "A * B\n" << buf << endl;
        buf = a.divMatrix(b);
        cout << "A / B\n" << buf << endl;
        cout << endl << endl;
    }

    cout << "=== MATH WITH NUM ===" << endl;
    {
        Matrix<float> a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        float b = -10.5;
        Matrix<float> buf;
        cout << "INIT A\n" << a << endl;
        cout << "INIT B\n" << b << endl << endl;
        cout << "--- MATH WIH NUMBER (operations) ---" << endl;
        buf = a + b;
        cout << "A + B\n" << buf << endl;
        buf = a - b;
        cout << "A - B\n" << buf << endl;
        buf = a * b;
        cout << "A * B\n" << buf << endl;
        buf = a / b;
        cout << "A / B\n" << buf << endl;
        cout << "\n";

        cout << "--- MATH WITH NUMBER (methods) ---" << endl;
        buf = a.addEntity(b);
        cout << "A + B\n" << buf << endl;
        buf = a.subEntity(b);
        cout << "A - B\n" << buf << endl;
        buf = a.mulEntity(b);
        cout << "A * B\n" << buf << endl;
        buf = a.divEntity(b);
        cout << "A / B\n" << buf << endl;
        cout << endl << endl;
        a.addEntity(5);
    }

    cout << "=== MATH WITH COPY ===" << endl;
    {
        Matrix<float> a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        Matrix<float> b({{7, 4, 2}, {1, -5, -6}, {1, 0, 1}});
        float buf = -100;
        cout << "INIT A\n" << a << endl;
        cout << "INIT B\n" << b << endl;
        cout << "--- MATH BETWEEN MATRIX ---" << endl;
        a.addToMatrix(b);
        cout << "A += B\n" << a << endl;
        a.subToMatrix(b);
        cout << "A -= B\n" << a << endl;
        a.mulToMatrix(b);
        cout << "A *= B\n" << a << endl;
        a.divToMatrix(b);
        cout << "A /= B\n" << a << endl;
        cout << "\n";

        cout << "--- MATH WITH NUMBER (methods) ---" << endl;
        cout << "INIT BUF\n" << buf << endl;
        a.addToEntity(buf);
        cout << "A += buf\n" << a << endl;
        a.subToEntity(buf);
        cout << "A -= buf\n" << a << endl;
        a.mulToEntity(buf);
        cout << "A *= buf\n" << a << endl;
        a.divToEntity(buf);
        cout << "A /= buf\n" << a << endl;
        cout << endl << endl;
    }

    cout << "=== MATRIX OPERATIONS ===" << endl;
    {
        Matrix<int> a = {{1, 2, 3,}, {4, 5, 6}};
        Matrix<int> buffer;
        cout << "INIT A\n" << a << endl;
        buffer = a.transpose();
        cout << "Transpose A\n" << buffer << endl;
        buffer = a.negative();
        cout << "Negative A\n" << buffer << endl;
        Matrix<int> b = {{1, 2}, {4, 5}};
        buffer = b.inverse();
        cout << "Inverse B {1, 2}, {3, 4}\n" << buffer << endl;
        cout << endl << endl;
    }

    cout << "=== ITERATORS ===" << endl;
    {
        cout << "--- ITERATORS not const matrix ---" << endl;
        Matrix<int> a = {{1, 2, 3,}, {4, 5, 6}};
        cout << "INIT A\n" << a << endl;

        cout << "For each const auto &elem with separate ' '\n";
        for (const auto &elem: a)
            cout << elem << " ";
        cout << endl;
        cout << "For each reverse auto &elem with separate ' '\n";
        for (auto rit = a.rbegin(); rit != a.rend(); ++rit)
            std::cout << *rit << " ";
        cout << "\nFor each const reverse auto &elem with separate ' '\n";
        const Matrix<int> &ca = a;
        for (auto rit = ca.rbegin(); rit != ca.rend(); ++rit)
            std::cout << *rit << " ";
        cout << endl;

        cout << "Change values of matrix\n";
        for (auto &elem: a)
            elem = 100 + elem;
        cout << a << endl;

        cout << "Filling \t from, to, filling\n";
        a.fill(a.begin(), a.end(), -100);
        cout << a << endl;

        cout << "Filling from another matrix \t from, from_val, from_to\n";
        Matrix<int> b = {{1, 2, 3,}, {4, 5, 6}};
        a.fill(a.begin(), b.begin(), b.end());
        cout << a << endl;

        cout << "Reverse matrix\n";
        a.reverse(a.begin(), a.end());
        cout << a << endl;

        cout << "--- ITERATORS const matrix ---" << endl;
        const Matrix<float> const_c = {{1., 2., 3.}, {4., 5., 6.}};
        cout << "For each const auto &elem with separate ' '\n";
        for (const auto &elem: const_c)
            cout << elem << " ";
        cout << endl;
        cout << "For each const reverse auto &elem with separate ' '\n";
        for (auto it = const_c.rbegin(); it != const_c.rend(); ++it)
            std::cout << *it << " ";
        cout << endl;
        cout << "For with cbegin and cend \n";
        cout << "Check of cbegin and cend methods of non-constant object (new_m matrix):\n";
        for (auto it = const_c.cbegin(); it < const_c.cend(); it++)
            cout << *it << " ";
        cout << endl;
        cout << "Check of crbegin and crend methods of non-constant object (new_m matrix):\n";
        for (auto it = const_c.crbegin(); it < const_c.crend(); it++)
            cout << *it << " ";
        cout << endl << endl;
    }

    cout << "=== RESIZE ===" << endl;
    {
        Matrix<float> a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        cout << "INIT A\n" << a << endl;
        cout << "SIZE OF A\n" << a.size() << endl << endl;
        cout << "INSERT ROW AT \t1 with fill 0\n";
        a.insertRow(1, 0);
        cout << a << endl;
        cout << "INSERT COL AT \t1 with fill 0\n";
        a.insertCol(1, 0);
        cout << a << endl;
        cout << "DELETE ROW AT \t1\n";
        a.deleteRow(1);
        cout << a << endl;
        cout << "DELETE COL AT \t1\n";
        a.deleteCol(1);
        cout << a << endl;
        cout << "RESIZE ROWS TO \ta.GetRows() + 1\n";
        a.resizeRows(a.GetRows() + 1, 9);
        cout << a << endl;
        cout << "RESIZE COLS TO \ta.GetCols() + 1\n";
        a.resizeCols(a.GetCols() + 1, 9);
        cout << a << endl;
        cout << "RESIZE ROWS AND COLS TO \ta.GetRows() + 1   a.GetCols() + 1\n";
        a.resize(a.GetRows() + 1, a.GetCols() + 1);
        cout << a << endl;
        cout << "RESIZE ROWS AND COLS TO \ta.GetRows() - 2   a.GetCols() - 2\n";
        a.resize(a.GetRows() - 2, a.GetCols() - 2);
        cout << a;
        cout << endl << endl;
    }


    cout << "!!! ERROR SEGMENT !!!" << endl;
    {
        cout << "!~Constructor with size below zero\n";
        try
        {
            Matrix<int> a(5, -1);
        }
        catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Wrong init list\n";
        try
        {
            Matrix<int> a = {{1, 2}, {3, 4, 5}};
        }
        catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Get non-exist column\n";
        Matrix<int> a(5, 5);
        try
        {
            a[3][100] = 4;
        }
        catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Get non-exist row\n";
        try
        {
            a[100][3] = 4;
        }
        catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Read expired iterator\n";
        try
        {
            Iterator<int> it = a.begin();
            {
                Matrix<int> buf = { { 1, 2 }, { 3, 4 } };
                it = buf.begin();
            }
            cout << *it;
        } catch (BaseException &err) {
            cout << err.what() << endl;
        }
        cout << "!~Read iterator out of range\n";
        try
        {
            Iterator<int> it = a.end();
            cout << *it;
        } catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Sum of non-compatitve matrices\n";
        try
        {
            Matrix<int> b = {{1, 2}, {3, 4}};
            Matrix<int> c = {{1, 2}, {3, 4}, {5, 6}};
            b + c;
        } catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Mul of non-compatitive matrices\n";
        try
        {
            Matrix<int> b = {{1, 2}, {3, 4}};
            Matrix<int> c = {{1, 2}, {3, 4}, {5, 6}};
            b * c;
        } catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Div by zero val\n";
        try
        {
            Matrix<int> b = {{1, 2}, {3, 4}};
            int buf = 0;
            Matrix<int> c = b / buf;
        } catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
        cout << "!~Init with error vectors\n";
        try
        {
            cout << "Constructor with vectors \tv { {1, 2}, {3, 4}, {5, 6, 7} } g(v):\n";
            std::vector<std::vector<int>> v { {1, 2}, {3, 4}, {5, 6, 7} };
            Matrix<int> g(v);
            cout << g << endl;
        } catch (BaseException &err)
        {
            cout << err.what() << endl;
        }
    }

    cout << "=== MATH WITH DIFF TYPE OF MATRIX ===" << endl;
    {
        Matrix<int> a = {{5, 10}, {20, 25}};
        Matrix<float> b = {{-5, 4.5}, {2.5, 8}};
        Matrix<float> buf;
        buf = a + b;
        cout << "A + B \n" << buf << endl;
        buf = a - b;
        cout << "A - B \n" << buf << endl;
        buf = a * b;
        cout << "A * B \n" << buf << endl;
        buf = a - b;
        cout << "A / B \n" << buf << endl;
        buf = a.addMatrix(b);
        cout << "A + B (method) \n" << buf << endl;
        buf = a.subMatrix(b);
        cout << "A - B (method) \n" << buf << endl;
        buf = a.mulMatrix(b);
        cout << "A * B (method) \n" << buf << endl;
        buf = a.divMatrix(b);
        cout << "A / B (method) \n" << buf << endl;
    }

    return 0;
}
