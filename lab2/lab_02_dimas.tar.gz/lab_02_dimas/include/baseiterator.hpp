//
// Created by Дмитрий Жигунов on 27.04.2023.
//

#ifndef LAB_02_BASEITERATOR_HPP
#define LAB_02_BASEITERATOR_HPP


class BaseIterator
{
public:
    virtual ~BaseIterator() = 0;
protected:
    int _rows = 0;
    int _cols = 0;
    int _index = 0;
};

BaseIterator::~BaseIterator() {};

#endif //LAB_02_BASEITERATOR_HPP
