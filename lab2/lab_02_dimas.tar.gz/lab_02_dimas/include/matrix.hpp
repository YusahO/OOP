//
// Created by Дмитрий Жигунов on 16.04.2023.
//

#ifndef LAB_02_MATRIX_HPP
#define LAB_02_MATRIX_HPP



// Класс матрицы
namespace MyMatrix
{

template<typename Type>
using SharedPtr = std::shared_ptr<Type>;
using SizeType = size_t;


#include "basematrix.hpp"
#include "../implementation/iterator_impl.hpp"
#include "../implementation/iterator_const_impl.hpp"
#include "../implementation/iterator_reverse_impl.hpp"
#include "../implementation/iterator_reverse_const_impl.hpp"
#include "exception.hpp"


template <typename From, typename To>
concept Convertable = std::convertible_to<From, To>;
template <typename From, typename To>
concept Assignable = requires(From fm, To to)
{
    to = fm;
};
template <typename Type>
concept ContainerC = requires(Type t)
{
    typename Type::value_type;
    typename Type::value_type::value_type;
    typename Type::size_type;
    typename Type::iterator;
    typename Type::const_iterator;

    { t.size() } noexcept -> std::same_as<typename Type::size_type>;
    { t.end() } noexcept -> std::same_as<typename Type::iterator>;
    { t.begin() } noexcept -> std::same_as<typename Type::iterator>;
    { t[0] } -> std::same_as<typename Type::value_type&>;
    { t[0][0] } -> std::same_as<typename Type::value_type::value_type&>;
};
template <typename T, typename U>
concept SumC = requires (T x, U y)
{
    x + y;
    y + x;
    { x + y } -> std::same_as<decltype(y + x)>;
    x + y == y + x;
};
template <typename T, typename U>
concept SubC = requires (T x, U y)
{
    x - y;
    y - x;
};
template <typename T, typename U>
concept MulC = requires (T x, U y)
{
    x * y;
    y * x;
    { x * y } -> std::same_as<decltype(y * x)>;
    x * y == y * x;
};
template <typename T, typename U>
concept DivC = requires (T x, U y)
{
    x / y;
    y / x;
};


template<typename T>
class Matrix: public BaseMatrix
{
public:
    using value_type = T;
    using size_type = size_t;
    using iterator = Iterator<T>;
    using iterator_const = IteratorConst<T>;
    using iterator_reverse = IteratorReverse<T>;
    using iterator_reverse_const = IteratorReverseConst<T>;

    class MatrixRow;
    friend Iterator<T>;
    friend IteratorConst<T>;
    friend IteratorReverse<T>;
    friend IteratorReverseConst<T>;
public:
    // Конструкторы
    explicit Matrix(SizeType rows = 0, SizeType cols = 0);
    Matrix(SizeType rows, SizeType cols, const T& filler);
    Matrix(SizeType rows, SizeType cols, const T *matrix);
    Matrix(SizeType rows, SizeType cols, iterator st);
    Matrix(std::initializer_list<std::initializer_list<T>> lt);
    Matrix(const Matrix& matrix);
    template<Convertable<T> U>
    explicit Matrix(const Matrix<U>& matrix);
    template<ContainerC Con>
    requires Convertable<typename Con::value_type::value_type, T> && Assignable<typename Con::value_type::value_type, T>
    explicit Matrix(const Con& matrix);

    Matrix(Matrix&& matrix) noexcept ;
    // Деструктор
    virtual ~Matrix() = default;

    Matrix<T>& operator=(std::initializer_list<std::initializer_list<T>> lt);
    Matrix<T>& operator=(const Matrix& matr);
    Matrix<T>& operator=(Matrix&& matr) noexcept ;


    bool isSquare();
    // Определитель матрицы
    T det();
    // Обратная матрица
    Matrix<T> inverse();
    // Изменение знака
    Matrix<T> operator-();
    Matrix<T> transpose();
    Matrix<T> negative();

    // Итераторы с заполнением
    void fill(iterator st, iterator end, const T& val);
    void fill(iterator st, iterator val_st, iterator val_end);
    void fill(iterator st, iterator_const val_st, iterator_const val_end);
    void reverse(iterator st, iterator end);

    // Сумма с матрицей
    template<SumC<T> U>
    Matrix<std::common_type_t<T, U>> operator+(const Matrix<U>& it) const;
    Matrix<T>& operator+=(const Matrix& it);
    template<SumC<T> U>
    Matrix<std::common_type_t<T, U>> addMatrix(const Matrix<U>& it) const;
    Matrix<T>& addToMatrix(const Matrix& it);

    // Сумма с числом
    template<SumC<T> U>
    Matrix<std::common_type_t<T, U>> operator+(const U& val) const;
    Matrix<T>& operator+=(const T& val);
    template<SumC<T> U>
    Matrix<std::common_type_t<T, U>> addEntity(const U& val) const;
    Matrix<T>& addToEntity(const T& val);

    // Разница с матрицей
    template<SubC<T> U>
    Matrix<std::common_type_t<T, U>> operator-(const Matrix<U>& it) const;
    Matrix<T>& operator-=(const Matrix& it);
    template<SubC<T> U>
    Matrix<std::common_type_t<T, U>> subMatrix(const Matrix<U>& it) const;
    Matrix<T>& subToMatrix(const Matrix& it);

    // Разница с числом
    template<SubC<T> U>
    Matrix<std::common_type_t<T, U>> operator-(const U& val) const;
    Matrix<T>& operator-=(const T& val);
    template<SubC<T> U>
    Matrix<std::common_type_t<T, U>> subEntity(const U& val) const;
    Matrix<T>& subToEntity(const T& val);


    // Умножение с матрицей
    template<MulC<T> U>
    Matrix<std::common_type_t<T, U>> operator*(const Matrix<U>& it) const;
    Matrix<T>& operator*=(const Matrix& it);
    template<MulC<T> U>
    Matrix<std::common_type_t<T, U>> mulMatrix(const Matrix<U>& it) const;
    Matrix<T>& mulToMatrix(const Matrix& it);

    // Умножение с числом
    template<MulC<T> U>
    Matrix<std::common_type_t<T, U>> operator*(const U& val) const;
    Matrix<T>& operator*=(const T& val);
    template<MulC<T> U>
    Matrix<std::common_type_t<T, U>> mulEntity(const U& val) const;
    Matrix<T>& mulToEntity(const T& val);


    // Деление с матрицей
    template<DivC<T> U>
    Matrix<std::common_type_t<T, U>> operator/(const Matrix<U>& it) const;
    Matrix<T>& operator/=(const Matrix& it);
    template<DivC<T> U>
    Matrix<std::common_type_t<T, U>> divMatrix(const Matrix<U>& it) const;
    Matrix<T>& divToMatrix(const Matrix& it);

    // Деление с числом
    template<DivC<T> U>
    Matrix<std::common_type_t<T, U>> operator/(const U& val) const;
    Matrix<T>& operator/=(const T& val);
    template<DivC<T> U>
    Matrix<std::common_type_t<T, U>> divEntity(const U& val) const;
    Matrix<T>& divToEntity(const T& val);


    // Изменение размера
    bool isSquare() const;
    void resize(SizeType n_rows, SizeType n_cols, const T& fill = {});
    void resizeRows(SizeType n_rows, const T& fill = {});
    void resizeCols(SizeType n_cols, const T& fill = {});
    void insertRow(SizeType ind, const T& fill_val);
    void insertCol(SizeType ind, const T& fill_val);
    void deleteRow(SizeType ind);
    void deleteCol(SizeType ind);
    void _moveRow(SizeType ind, SizeType new_ind);
    void _moveCol(SizeType ind, SizeType new_ind);


    // Итераторы
    iterator begin() noexcept;
    iterator end() noexcept;

    iterator_const begin() const noexcept;
    iterator_const end() const noexcept;
    iterator_const cbegin() const noexcept;
    iterator_const cend() const noexcept;

    iterator_reverse rbegin() noexcept;
    iterator_reverse rend() noexcept;

    iterator_reverse_const rbegin() const noexcept;
    iterator_reverse_const rend() const noexcept;
    iterator_reverse_const crbegin() const noexcept;
    iterator_reverse_const crend() const noexcept;


    T& at(SizeType row, SizeType col);
    const T& at(SizeType row, SizeType col) const;
    void set(SizeType n, SizeType m, T val);
    T& operator()(SizeType row, SizeType col);
    MatrixRow operator[](SizeType row);
    const MatrixRow operator[](SizeType row) const;

private:
    SharedPtr<MatrixRow[]> _data {nullptr};
    SharedPtr<MatrixRow[]> _allocate_mem(SizeType rows, SizeType cols);
    void _checkLimit(SizeType ind, SizeType limit) const;
    // Сравнение размеров двух матриц
    template<typename U>
    void _checkSizes(Matrix<U> matr) const;
    template<typename U>
    void _checkSizesMulti(Matrix<U> matr) const;
    // Проверка на деление
    template<typename U>
    void _checkDiv(const U& val) const;

    void _checkType();
    T _det(const Matrix<T>& matrix);

// Подкласс MatrixRow
public:
    class MatrixRow {
        friend Iterator<T>;
        friend IteratorConst<T>;
    private:
        SharedPtr<T[]> _data = nullptr;
        SizeType _size = 0;
    public:
        MatrixRow(T *data, const SizeType size): _data(data), _size(size) {};
        MatrixRow();
        T& operator[](SizeType index);
        const T& operator[](SizeType index) const;
        void reset(T *data, SizeType len);
        void reset();
        T* getAddr() { return _data.get(); }
        const T* getAddr() const { return _data.get(); }
    };
};


#include "../implementation/matrix_impl.hpp"
#include "../implementation/matrix_row.hpp"
#include "../implementation/matrix_iterator.hpp"
#include "../implementation/matrix_resize.hpp"
#include "../implementation/matrix_math.hpp"
#include "../implementation/matrix_arifmetic_m.hpp"
#include "../implementation/matrix_arifmetic_e.hpp"
}


#endif //LAB_02_MATRIX_HPP
