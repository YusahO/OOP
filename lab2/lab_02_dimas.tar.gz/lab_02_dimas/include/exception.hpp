//
// Created by Дмитрий Жигунов on 15.04.2023.
//

#ifndef LAB_02_EXCEPTION_HPP
#define LAB_02_EXCEPTION_HPP

#include <exception>
#include <string>
#include <ctime>


class BaseException: public std::exception
{
public:
    BaseException(const char * fname, const size_t line, const char * time, const char * msg)
    {
        char buf[64] = { '\0' };
        strcat(err_msg, "ERROR\nFile: ");
        strcat(err_msg, fname);
        strcat(err_msg, "\nLine: ");
        snprintf(buf, 8, "%ld", line);
        strcat(err_msg, buf);
        strcat(err_msg, "\nTime: ");
        strcat(err_msg, time);
        strcat(err_msg, "Info: ");
        strcat(err_msg, msg);
    }

    virtual const char* what() const noexcept override
    {
        return err_msg;
    }

private:
    char err_msg[512] = { "\0" };
};


class ErrorIndex : public BaseException
{
public:
    ErrorIndex(const char *fname, const size_t line, const char *time, const char *msg) :
    BaseException(fname, line, time, msg) {} ;
};
// Ошибка памяти
class ErrorMemory : public BaseException
{
public:
    ErrorMemory(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time, msg) {} ;
};
// Ошибка итератора
class ErrorIterator : public BaseException
{
public:
    ErrorIterator(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time, msg) {} ;
};
// Ошибка итератора
class ErrorIteratorIndex : public BaseException
{
public:
    ErrorIteratorIndex(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time, msg) {} ;
};
// Ошибка совместимости
class ErrorCompatibility : public BaseException
{
public:
    ErrorCompatibility(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time, msg) {} ;
};
// Ошибка типа
class ErrorType : public BaseException
{
public:
    ErrorType(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time, msg) {} ;
};
// Деление на 0
class ErrorZeroDiv : public BaseException
{
public:
    ErrorZeroDiv(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time,msg) {} ;
};
// Ошибка параметров
class ErrorArg : public BaseException
{
public:
    ErrorArg(const char *fname, const size_t line, const char *time, const char *msg) :
            BaseException(fname, line, time, msg) {} ;
};




#endif //LAB_02_EXCEPTION_HPP
