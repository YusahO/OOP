//
// Created by Дмитрий Жигунов on 15.04.2023.
//

#ifndef LAB_02_BASEMATRIX_HPP
#define LAB_02_BASEMATRIX_HPP

#include <iostream>
#include <new>
#include <memory>
#include <iterator>
#include <initializer_list>

#include "iterator.hpp"
#include "exception.hpp"

using std::shared_ptr;


// Базовый класс матрицы
class BaseMatrix
{
public:
    explicit BaseMatrix(const size_t rows = 0, const size_t columns = 0)
    {
        this->_rows = rows;
        this->_cols = columns;
    }

    size_t GetRows() const noexcept { return this->_rows; }
    size_t GetCols() const noexcept { return this->_cols; }
    size_t size() const noexcept { return this->_rows * this->_cols; }

    virtual ~BaseMatrix() = 0;
protected:
    size_t _rows;
    size_t _cols;
};

BaseMatrix::~BaseMatrix() {};


#endif //LAB_02_BASEMATRIX_HPP
