//
// Created by Дмитрий Жигунов on 15.04.2023.
//

#ifndef LAB_02_ITERATORReverse_HPP
#define LAB_02_ITERATORReverse_HPP

#include <iostream>
#include <iterator>
#include "baseiterator.hpp"
#include "exception.hpp"

template<typename T>
class Matrix;

template<typename T>
class IteratorReverse : BaseIterator
{
public:
    using iterator_category = std::random_access_iterator_tag;
    using value_type = T;
    using difference_type = std::ptrdiff_t;
    using pointer = value_type*;
    using reference = value_type&;
public:
    IteratorReverse(const Matrix<T> &matrix, const size_t index = 0, const bool is_reverse = 0): _data(matrix._data), _index(index),
                                                                  _rows(matrix._rows), _cols(matrix._cols), _is_reverse(is_reverse) {}
    IteratorReverse(const IteratorReverse &it) = default;

    // Сравнение итераторов
    bool operator!=(IteratorReverse const& it) const { return _index != it._index; };
    bool operator==(IteratorReverse const& it) const { return _index == it._index; };
    bool operator<(IteratorReverse const& it) const { return _index < it._index; };
    bool operator<=(IteratorReverse const& it) const { return _index <= it._index; };
    bool operator>(IteratorReverse const& it) const { return _index > it._index; };
    bool operator>=(IteratorReverse const& it) const { return _index >= it._index; };

    operator bool() const { return _data.expired(); };
    bool isEnd() const {return _index == _rows * _cols; }
    bool isValid() const {return !_data.expired(); };

    reference operator*();
    const reference operator*() const;

    pointer operator->();
    const pointer operator->() const;
    reference operator[](int ind) const;

    IteratorReverse<T> operator+(const int value) const;
    IteratorReverse<T> operator-(const int value) const;
    difference_type operator-(const  Iterator<value_type>& other) const { return std::distance(other._data, _data); }
    IteratorReverse<T> &operator=(const IteratorReverse<T> &it);

    // Итерировать контейнерные элементы
    IteratorReverse<T>& operator++();
    IteratorReverse<T> operator++(int);
    IteratorReverse<T> next();
    IteratorReverse<T>& operator--();
    IteratorReverse<T> operator--(int);
    IteratorReverse<T> prev();

private:
    void _checkIndex(const std::string msg);
    void _checkValid(const std::string msg);

    // weak_ptr не отвечает за освобождение памяти из под объект
    // он может только проверить, есть объект или нет
    std::weak_ptr<typename Matrix<T>::MatrixRow[]> _data = nullptr;
    bool _is_reverse = false;
    size_t _rows = 0;
    size_t _cols = 0;
    size_t _index = 0;
};


#include "../implementation/iterator_reverse_impl.hpp"

#endif //LAB_02_ITERATORReverse_HPP
