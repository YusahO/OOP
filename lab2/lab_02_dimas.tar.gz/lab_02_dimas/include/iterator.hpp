//
// Created by Дмитрий Жигунов on 15.04.2023.
//

#ifndef LAB_02_ITERATOR_HPP
#define LAB_02_ITERATOR_HPP

#include <iostream>
#include <iterator>
#include "baseiterator.hpp"
#include "exception.hpp"

template<typename T>
class Matrix;

template<typename T>
class Iterator : BaseIterator
{
public:
    using iterator_category = std::random_access_iterator_tag;
    using value_type = T;
    using difference_type = std::ptrdiff_t;
    using pointer = value_type*;
    using reference = value_type&;
public:
    Iterator(const Matrix<value_type> &matrix, const size_t index = 0, const bool is_reverse = 0): _data(matrix._data), _index(index),
                                                                  _rows(matrix._rows), _cols(matrix._cols) {}
    Iterator(const Iterator &it) = default;


    // Сравнение итераторов
    bool operator!=(Iterator const& it) const { return _index != it._index; };
    bool operator==(Iterator const& it) const { return _index == it._index; };
    bool operator<(Iterator const& it) const { return _index < it._index; };
    bool operator<=(Iterator const& it) const { return _index <= it._index; };
    bool operator>(Iterator const& it) const { return _index > it._index; };
    bool operator>=(Iterator const& it) const { return _index >= it._index; };

    operator bool() const { return _data.expired(); };
    bool isEnd() const {return _index == _rows * _cols; }
    bool isValid() const {return !_data.expired(); };

    reference operator*();
    const reference operator*() const;
    pointer operator->();
    const pointer operator->() const;
    reference operator[](int ind) const;

    Iterator<value_type> operator+(const int value) const;
    Iterator<value_type> operator-(const int value) const;
    Iterator<value_type> &operator=(const Iterator<value_type> &it);
    difference_type operator-(const  Iterator<value_type>& other) const { return std::distance(other._data, _data); }

    // Итерировать контейнерные элементы
    Iterator<value_type>& operator++();
    Iterator<value_type> operator++(int);
    Iterator<value_type> next();
    Iterator<value_type>& operator--();
    Iterator<value_type> operator--(int);
    Iterator<value_type> prev();

private:
    void _checkIndex(const std::string msg);
    void _checkValid(const std::string msg);

    // weak_ptr не отвечает за освобождение памяти из под объект
    // он может только проверить, есть объект или нет
    std::weak_ptr<typename Matrix<T>::MatrixRow[]> _data = nullptr;
    size_t _rows = 0;
    size_t _cols = 0;
    size_t _index = 0;
};

#endif //LAB_02_ITERATOR_HPP
