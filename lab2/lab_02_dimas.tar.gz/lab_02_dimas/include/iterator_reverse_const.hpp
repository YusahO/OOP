//
// Created by Дмитрий Жигунов on 21.04.2023.
//

#ifndef LAB_02_ITERATOR_REVERSE_CONST_HPP
#define LAB_02_ITERATOR_REVERSE_CONST_HPP

#include <iostream>
#include <iterator>
#include "baseiterator.hpp"
#include "exception.hpp"

template<typename T>
class Matrix;

template<typename T>
class IteratorReverseConst : BaseIterator
{
public:
    using iterator_category = std::random_access_iterator_tag;
    using value_type = T;
    using difference_type = std::ptrdiff_t;
    using pointer = value_type*;
    using reference = value_type&;
public:
    IteratorReverseConst(const Matrix<T> &matrix, const size_t index = 0): _data(matrix._data), _index(index),
                                                               _rows(matrix._rows), _cols(matrix._cols) {}
    IteratorReverseConst(const IteratorReverseConst &it) = default;

    // Сравнение итераторов
    bool operator!=(IteratorReverseConst const& it) const { return _index != it._index; };
    bool operator==(IteratorReverseConst const& it) const { return _index == it._index; };
    bool operator<(IteratorReverseConst const& it) const { return _index < it._index; };
    bool operator<=(IteratorReverseConst const& it) const { return _index <= it._index; };
    bool operator>(IteratorReverseConst const& it) const { return _index > it._index; };
    bool operator>=(IteratorReverseConst const& it) const { return _index >= it._index; };

    operator bool() const { return _data.expired(); };
    bool isEnd() const {return _index == _rows * _cols; }
    bool isValid() const {return !_data.expired(); };

    const reference operator*() const;
    const pointer operator->() const;
    reference operator[](int ind) const;


    IteratorReverseConst<T> operator+(const int value) const;
    IteratorReverseConst<T> operator-(const int value) const;
    IteratorReverseConst<T> &operator=(const IteratorReverseConst<T> &it);
    difference_type operator-(const  Iterator<value_type>& other) const { return std::distance(other._data, _data); }

    // Итерировать контейнерные элементы
    IteratorReverseConst<T>& operator++();
    IteratorReverseConst<T> operator++(int);
    IteratorReverseConst<T> next();
    IteratorReverseConst<T>& operator--();
    IteratorReverseConst<T> operator--(int);
    IteratorReverseConst<T> prev();

private:
    void _checkValid(const std::string& msg = "Unknown") const;
    void _checkIndex(const std::string& msg = "Unknown") const;

    // weak_ptr не отвечает за освобождение памяти из под объекта
    // он может только проверить, есть объект или нет
    std::weak_ptr<typename Matrix<T>::MatrixRow[]> _data = nullptr;
    size_t _rows = 0;
    size_t _cols = 0;
    size_t _index = 0;
};


#include "../implementation/iterator_reverse_const_impl.hpp"

#endif //LAB_02_ITERATOR_REVERSE_CONST_HPP
