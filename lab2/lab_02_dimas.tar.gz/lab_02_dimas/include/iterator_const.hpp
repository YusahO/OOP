//
// Created by Дмитрий Жигунов on 21.04.2023.
//

#ifndef LAB_02_ITERATOR_CONST_HPP
#define LAB_02_ITERATOR_CONST_HPP

#include <iostream>
#include <iterator>
#include "baseiterator.hpp"
#include "exception.hpp"

template<typename T>
class Matrix;


template<typename T>
class IteratorConst : BaseIterator
{
public:
    using iterator_category = std::random_access_iterator_tag;
    using value_type = T;
    using difference_type = std::ptrdiff_t;
    using pointer = value_type*;
    using reference = value_type&;
public:
    IteratorConst(const Matrix<T> &matrix, const size_t index = 0): _data(matrix._data), _index(index),
                                                               _rows(matrix._rows), _cols(matrix._cols) {}
    IteratorConst(const IteratorConst &it) = default;

    // Сравнение итераторов
    bool operator!=(IteratorConst const& it) const { return _index != it._index; };
    bool operator==(IteratorConst const& it) const { return _index == it._index; };
    bool operator<(IteratorConst const& it) const { return _index < it._index; };
    bool operator<=(IteratorConst const& it) const { return _index <= it._index; };
    bool operator>(IteratorConst const& it) const { return _index > it._index; };
    bool operator>=(IteratorConst const& it) const { return _index >= it._index; };

    operator bool() const { return _data.expired(); };
    bool isEnd() const {return _index == _rows * _cols; }
    bool isValid() const {return !_data.expired(); };

    const reference operator*() const;
    const pointer operator->() const;
    reference operator[](int ind) const;

    IteratorConst<T> operator+(const int value) const;
    IteratorConst<T> operator-(const int value) const;
    IteratorConst<T> &operator=(const IteratorConst<T> &it);
    difference_type operator-(const  Iterator<value_type>& other) const { return std::distance(other._data, _data); }

    // Итерировать контейнерные элементы
    IteratorConst<T>& operator++();
    IteratorConst<T> operator++(int);
    IteratorConst<T> next();
    IteratorConst<T>& operator--();
    IteratorConst<T> operator--(int);
    IteratorConst<T> prev();

private:
    void _checkValid(const std::string& msg = "Unknown") const;
    void _checkIndex(const std::string& msg = "Unknown") const;

    // weak_ptr не отвечает за освобождение памяти из под объекта
    // он может только проверить, есть объект или нет
    std::weak_ptr<typename Matrix<T>::MatrixRow[]> _data = nullptr;
    size_t _rows = 0;
    size_t _cols = 0;
    size_t _index = 0;
};


#include "../implementation/iterator_const_impl.hpp"

#endif //LAB_02_ITERATOR_CONST_HPP
